def agregar_libro(inventario):
    titulo=input("Ingrese el titulo del libro: ")
    autor=input("Ingrese el nombre del autor: ")
    cantidad=int(input("Ingrese la cantidad de libros: "))
    inventario[titulo]={"autor":autor,"cantidad":cantidad}
    print(f"Libro: '{titulo}' agregado al inventario")

def mostrar_inventario(inventario):
    print("\n---Inventario de libros---")
    for titulo,libro in inventario.items():
        print(f"Titulo: {titulo}, Autor: {libro['autor']}, Cantidad: {libro['cantidad']}")