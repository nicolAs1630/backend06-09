def vender_libro(inventario, ventas):
    titulo=input("Ingrese el titulo del libro que desea vender: ")
    if titulo in inventario:
        cantidad_ventas=int(input("Ingrese la cantidad de libros vendidos: "))
        if cantidad_ventas<=inventario[titulo]["cantidad"]:
            inventario[titulo]["cantidad"] -= cantidad_ventas
            ventas[titulo] = ventas.get(titulo, 0) + cantidad_ventas
            print(f"Se vendieron {cantidad_ventas} copias del libro '{titulo}'")
        else:
            print("No hay suficientes copias del libro en el inventario")

def mostrar_ventas(ventas):
    print("\n---Total de Ventas---")
    for titulo, cantidad in ventas.items():
        print(f"Titulo: {titulo}, cantidad vendida: {cantidad}")