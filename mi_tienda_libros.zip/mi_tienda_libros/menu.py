def mostrar_menu():
    """Muestra el menú principal"""
    print("\n-- Menú de la tienda de libros ---")
    print("1. Agregar libro al inventario")
    print("2. Mostrar inventario")
    print("3. Vender libro")
    print("4. Mostrar total de ventas")
    print("5. Salir")