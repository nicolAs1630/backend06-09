from gestion_libros.inventario import mostrar_inventario, agregar_libro
from gestion_libros.ventas import mostrar_ventas, vender_libro
from menu import mostrar_menu

def main():
    inventario={}
    ventas={}
    while True:
        mostrar_menu()
        opcion=int(input("Ingrese un numero: "))
        if opcion==1:
            agregar_libro(inventario)
        elif opcion==2:
            mostrar_inventario(inventario)
        elif opcion==3:
            vender_libro(inventario, ventas)
        elif opcion==4:
            mostrar_ventas(ventas)
        elif opcion==5:
            print("Saliendo del programa")
            break
        else:
            print("Opción invalida, por favor ingrese un numero correctamente")


main()